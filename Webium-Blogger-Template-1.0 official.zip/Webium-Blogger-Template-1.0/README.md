# Webium Blogger Template
Webium is a Free Blogger Template that looks very similar to the Medium.com.

<img style='width:100%' src='https://github.com/elhakimyasya/Webium-Blogger-Template/blob/main/preview.png'>

# More Info
- [Documentations](https://webium-blogger.blogspot.com/p/webium-documentations.html);
- [Official Website](https://www.elcreativeacademy.com/)
